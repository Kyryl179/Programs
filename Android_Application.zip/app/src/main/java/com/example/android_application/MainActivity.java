package com.example.android_application;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.android_application.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button go_to_youtube_button;
    SeekBar seekbar;
    TextView textView;
    TextView Rand_Num;
    final Random random = new Random();
    public int seek_bar_val = 5000;
    @Override
    protected  void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekbar = (SeekBar)findViewById(R.id.seekBar);
        textView = (TextView)findViewById(R.id.textView3);
        Rand_Num = (TextView)findViewById(R.id.textView4);


        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setText(String.valueOf(progress));
                seek_bar_val = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        go_to_youtube_button=(Button)findViewById(R.id.go_to_yt);
        go_to_youtube_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if(seek_bar_val>0) {
                    Rand_Num.setText(String.valueOf(random.nextInt(seek_bar_val)));
                }
                else{
                    Rand_Num.setText("-----");
                }
            }
        });




    }

}